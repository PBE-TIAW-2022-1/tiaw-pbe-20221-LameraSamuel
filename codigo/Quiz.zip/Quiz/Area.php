<?php
//include_once 'conexão.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Quiz</title>
	<link rel="stylesheet" href="reset.css">
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="../css/home.css">
	
</head>

<body>
<div class="header">
			<div class="header-right">
				<a class="active" href="../home.php">Home</a>
				<a href="index.php">Quiz</a>
				<a href="../paginaconstrução.html">Sobre</a>
			</div>  


		
		</div>

		<h1 class='mock'> Pagina em Construção </h1>
</body>
</html>